function showMessage() {
    alert("Hello! Thanks for visiting.");
}
;
